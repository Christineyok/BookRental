import java.time.LocalDate;

public class Employee {
    private int employeeId;
    private String name;
    private String contact;

    public Employee(int employeeId, String name, String contact) {
        this.employeeId = employeeId;
        this.name = name;
        this.contact = contact;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public void rentBook(Customer customer, Book book, LocalDate dueDate, Library library) {
        library.rentBook(customer, book, dueDate);
    }

    public void returnBook(Rental rental, Library library) {
        rental.getRentedBook().setAvailable(true);
        rental.setStatus("Returned");
        rental.getRentedCustomer().returnBook(rental);

        library.updateRentalStatus(rental);
    }

    public String toString() {
        return "Employee ID: " + employeeId + "\nName: " + name + "\nContact: " + contact;
    }

    // You can add more methods for other library management tasks
}
