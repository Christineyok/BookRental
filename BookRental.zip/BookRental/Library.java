import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Library {
    private List<Book> books;
    private List<Customer> customers;
    private List<Rental> rentals;
    private List<Employee> employees; // Add this list
    private int nextRentalId = 1;
    private int nextBookId = 1;
    private int nextCustomerId = 1;
    private int nextEmployeeId; // Keep track of the next employee ID

    public Library() {
        this.books = new ArrayList<>();
        this.customers = new ArrayList<>();
        this.rentals = new ArrayList<>();
        this.employees = new ArrayList<>();
        nextBookId = 1;
        nextCustomerId = 1;
        nextRentalId = 1;
        nextEmployeeId = 1; // Initialize the next employee ID
    }

    public List<Book> getBooks() {
        return books;
    }

    public List<Customer> getCustomers() {
        return customers;
    }

    public List<Rental> getRentals() {
        return rentals;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void addRental(Rental rental) {
        rentals.add(rental);
    }

    public int getNextRentalId() {
        return nextRentalId++;
    }

    public int getNextBookId() {
        return nextBookId++;
    }

    public int getNextCustomerId() {
        return nextCustomerId++;
    }

    public int getNextEmployeeId() {
        return nextEmployeeId++;
    }

    public Book getBookById(int bookId) {
        for (Book book : books) {
            if (book.getBookId() == bookId) {
                return book;
            }
        }
        return null;
    }

    public Customer getCustomerById(int customerId) {
        for (Customer customer : customers) {
            if (customer.getCustomerId() == customerId) {
                return customer;
            }
        }
        return null;
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void addCustomer(Customer customer) {
        customers.add(customer);
    }

    public void rentBook(Customer customer, Book book, LocalDate dueDate) {
        if (!book.isAvailable()) {
            System.out.println("Book is not available for rent.");
            return;
        }

        Rental rental = new Rental(nextRentalId++, book, LocalDate.now(), dueDate, customer);
        customer.rentBook(rental);
        book.setAvailable(false);
        rentals.add(rental);

        System.out.println("Book rented successfully.");
    }

    public void returnBook(int rentalId) {
        Rental rental = getRentalById(rentalId);

        if (rental != null) {
            rental.getRentedBook().setAvailable(true);
            rental.setStatus("Returned");
            rental.getRentedCustomer().returnBook(rental);

            updateRentalStatus(rental);
            System.out.println("Book returned successfully.");
        } else {
            System.out.println("Rental not found.");
        }
    }

    public void displayBooks() {
        System.out.println("Available books in the library:");
        for (Book book : books) {
            if (book.isAvailable()) {
                System.out.println(book);
            }
        }
    }

    public void displayCustomers() {
        System.out.println("Registered customers:");
        for (Customer customer : customers) {
            System.out.println(customer);
        }
    }

    public void displayRentals() {
        System.out.println("Active rentals:");
        for (Rental rental : rentals) {
            if (rental.getStatus().equals("Active")) {
                System.out.println(rental);
            }
        }
    }

    public void displayEmployees() {
        System.out.println("Registered employees:");
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }

    public Rental getRentalById(int rentalId) {
        for (Rental rental : rentals) {
            if (rental.getRentalId() == rentalId) {
                return rental;
            }
        }
        return null;
    }

    public void updateRentalStatus(Rental rental) {
        for (Rental r : rentals) {
            if (r.getRentalId() == rental.getRentalId()) {
                r.setStatus("Returned");
                break;
            }
        }
    }

    // You can add more methods for other library management tasks
}
