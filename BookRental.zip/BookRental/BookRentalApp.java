import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.util.List;

public class BookRentalApp extends JFrame {
    private Library library;
    private Employee employee;

    private JButton addEmployeeButton;
    private JButton addBookButton;
    private JButton registerCustomerButton;
    private JButton rentBookButton;
    private JButton returnBookButton;
    private JTextArea displayArea;

    public BookRentalApp() {
        library = initializeLibrary();
        employee = null; // Initialize the employee as null

        // Create components
        // Inside the constructor, create and add the buttons to the buttonPanel
        addEmployeeButton = createStyledButton("Add Employee");
        addBookButton = createStyledButton("Add New Book");
        registerCustomerButton = createStyledButton("Register New Customer");
        rentBookButton = createStyledButton("Rent Book");
        returnBookButton = createStyledButton("Return Book");
        displayArea = createStyledTextArea();

        // Create panels for buttons and text area
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 5, 10, 10));
        buttonPanel.add(addEmployeeButton);
        buttonPanel.add(addBookButton);
        buttonPanel.add(registerCustomerButton);
        buttonPanel.add(rentBookButton);
        buttonPanel.add(returnBookButton);

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPanel.add(buttonPanel, BorderLayout.NORTH);
        contentPanel.add(new JScrollPane(displayArea), BorderLayout.CENTER);

        setContentPane(contentPanel);

        JScrollPane scrollPane = new JScrollPane(displayArea);

        // Apply modern style to buttons

        addEmployeeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addEmployee();
            }
        });

        addBookButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addNewBook();
            }
        });

        registerCustomerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registerNewCustomer();
            }
        });

        rentBookButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                rentBook();
            }
        });

        returnBookButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                returnBook();
            }
        });

        // Add components to the JFrame
        setLayout(new BorderLayout());
        add(buttonPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Set JFrame properties
        setTitle("Book Rental App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1500, 400);
        setLocationRelativeTo(null); // Center the JFrame on the screen
        setVisible(true);
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(Color.decode("#ff6b6b")); // Vibrant pink
        button.setForeground(Color.white);
        button.setFont(new Font("Comic Sans MS", Font.BOLD, 18)); // Playful font
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(16, 32, 16, 32)); // Increased padding

        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(Color.decode("#ff4d4d")); // Slightly darker pink on hover
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(Color.decode("#ff6b6b")); // Back to the original pink color
            }
        });

        return button;
    }

    private JTextArea createStyledTextArea() {
        JTextArea textArea = new JTextArea(10, 40);
        textArea.setEditable(false);
        textArea.setFont(new Font("Verdana", Font.PLAIN, 14)); // Clear font
        textArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.decode("#ffcccc"), 2), // Light pink border
                BorderFactory.createEmptyBorder(12, 12, 12, 12)));
        textArea.setBackground(Color.decode("#fff5f5")); // Very light pink background
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        return textArea;
    }

    private Library initializeLibrary() {
        Library library = new Library();
        return library;
    }

    private void addEmployee() {
        String name = JOptionPane.showInputDialog(this, "Enter employee name:");
        String contact = JOptionPane.showInputDialog(this, "Enter employee contact:");

        if (name != null && contact != null && !name.isEmpty() && !contact.isEmpty()) {
            Employee newEmployee = new Employee(library.getNextEmployeeId(), name, contact);
            library.addEmployee(newEmployee);
            employee = newEmployee; // Set the employee instance

            displayArea.append("New employee added!\n");
            displayBooksCustomersAndEmployees();
        }
    }

    private void addNewBook() {
        String bookTitle = JOptionPane.showInputDialog(this, "Enter book title:");
        String bookAuthor = JOptionPane.showInputDialog(this, "Enter book author:");
        String bookGenre = JOptionPane.showInputDialog(this, "Enter book genre:");

        if (bookTitle != null && bookAuthor != null && bookGenre != null) {
            Book newBook = new Book(library.getNextBookId(), bookTitle, bookAuthor, bookGenre, true);
            library.addBook(newBook);
            displayArea.append("New book added!\n");
            displayBooksCustomersAndEmployees();
        }
    }

    private void registerNewCustomer() {
        String customerName = JOptionPane.showInputDialog(this, "Enter customer name:");
        String customerAddress = JOptionPane.showInputDialog(this, "Enter customer address:");
        String customerEmail = JOptionPane.showInputDialog(this, "Enter customer email:");

        if (customerName != null && customerAddress != null && customerEmail != null) {
            Customer newCustomer = new Customer(library.getNextCustomerId(), customerName, customerAddress,
                    customerEmail);
            library.addCustomer(newCustomer);
            displayArea.append("New customer registered!\n");
            displayBooksCustomersAndEmployees();
        }
    }

    private void rentBook() {

        if (employee == null) {
            JOptionPane.showMessageDialog(this, "Employee is not set.");
            return;
        }

        String customerIdInput = JOptionPane.showInputDialog(this, "Enter customer ID:");
        String bookIdInput = JOptionPane.showInputDialog(this, "Enter book ID:");

        if (customerIdInput != null && bookIdInput != null) {
            int customerId = Integer.parseInt(customerIdInput);
            int bookId = Integer.parseInt(bookIdInput);

            Customer customer = library.getCustomerById(customerId);
            Book book = library.getBookById(bookId);

            if (customer == null || book == null) {
                JOptionPane.showMessageDialog(this, "Customer or book not found.");
                return;
            }

            LocalDate dueDate = LocalDate.now().plusDays(14);
            employee.rentBook(customer, book, dueDate, library);

            displayBooksCustomersAndEmployees();
        }
    }

    private void returnBook() {
        if (employee == null) {
            JOptionPane.showMessageDialog(this, "Employee is not set.");
            return;
        }

        String rentalIdInput = JOptionPane.showInputDialog(this, "Enter rental ID:");

        if (rentalIdInput != null) {
            int rentalId = Integer.parseInt(rentalIdInput);

            library.returnBook(rentalId);

            displayBooksCustomersAndEmployees();
        }
    }

    private void displayBooksCustomersAndEmployees() {
        displayArea.setText(""); // Clear the display area

        List<Book> books = library.getBooks();
        List<Customer> customers = library.getCustomers();
        List<Employee> employees = library.getEmployees();

        displayArea.append("\nEmployees:\n");
        for (Employee employee : employees) {
            displayArea.append(employee.toString() + "\n\n");
        }

        displayArea.append("Books:\n");
        for (Book book : books) {
            displayArea.append(book.toString() + "\n\n");
        }

        displayArea.append("\nCustomers:\n");
        for (Customer customer : customers) {
            displayArea.append(customer.toString() + "\n\n");
        }

        displayArea.append("Current Rentals:\n");
        for (Rental rental : library.getRentals()) {
            if (rental.getStatus().equals("Active")) {
                displayArea.append(rental.toString() + "\n");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new BookRentalApp();
        });
    }
}
