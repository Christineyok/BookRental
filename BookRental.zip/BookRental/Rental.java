import java.time.LocalDate;

public class Rental {
    private int rentalId;
    private Book rentedBook;
    private LocalDate rentalDate;
    private LocalDate dueDate;
    private String status;
    private Customer rentedCustomer;

    public Rental(int rentalId, Book rentedBook, LocalDate rentalDate, LocalDate dueDate, Customer rentedCustomer) {
        this.rentalId = rentalId;
        this.rentedBook = rentedBook;
        this.rentalDate = rentalDate;
        this.dueDate = dueDate;
        this.rentedCustomer = rentedCustomer;
        this.status = "Active"; // Assuming status is initialized as "Active"
    }

    public int getRentalId() {
        return rentalId;
    }

    public void setRentalId(int rentalId) {
        this.rentalId = rentalId;
    }

    public Book getRentedBook() {
        return rentedBook;
    }

    public void setRentedBook(Book rentedBook) {
        this.rentedBook = rentedBook;
    }

    public LocalDate getRentalDate() {
        return rentalDate;
    }

    public void setRentalDate(LocalDate rentalDate) {
        this.rentalDate = rentalDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Customer getRentedCustomer() {
        return rentedCustomer;
    }

    public void setRentedCustomer(Customer rentedCustomer) {
        this.rentedCustomer = rentedCustomer;
    }

    public String toString() {
        return "Rental ID: " + rentalId + "\n" +
                "Book Title: " + rentedBook.getTitle() + "\n" +
                "Rental Date: " + rentalDate + "\n" +
                "Due Date: " + dueDate + "\n" +
                "Status: " + status + "\n" +
                "Customer Name: " + rentedCustomer.getName() + "\n";
    }
}
